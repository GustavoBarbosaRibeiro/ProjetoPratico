
insert into categoria (id, nome, urlImagem) values (1, "Laticinios","resource/imagens/laticinios.jpg");
insert into categoria (id, nome, urlImagem) values (2, "Carnes", "resource/imagens/carnes.jpg");
insert into categoria (id, nome, urlImagem) values (3, "Padaria", "resource/imagens/padaria.jpg");
insert into categoria (id, nome, urlImagem) values (4, "Horti Fruti", "resource/imagens/hortifrutigranjeiros.jpg");


insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (1, "Leite 1", "resource/imagens/leite.jpg", "O puro leite de vaca", 1.00);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (1, "Leite 2", "resource/imagens/leite.jpg", "O puro leite de vaca 2");
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (1, "Leite 3", "resource/imagens/leite.jpg", "O puro leite de vaca 3", 4.00);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (1, "Leite 4", "resource/imagens/leite.jpg", "O puro leite de vaca 4", 0.50);

insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (2, "Carne 1", "resource/imagens/coxa.jpg", "A pura carne", 2.00);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (2, "Carne 2", "resource/imagens/coxa.jpg", "A pura carne 2", 3.00);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (2, "Carne 3", "resource/imagens/pernil.jpg", "A pura carne 3", 10.00);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (2, "Carne 4", "resource/imagens/pernil.jpg", "A pura carne 4", 12.00);


insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (3, "P�o 1", "resource/imagens/pao.jpg", "P�o fresco e quente", 0.40);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (3, "P�o 2", "resource/imagens/pao.jpg", "P�o fresco e quente 2", 0.50);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (3, "P�o 3", "resource/imagens/pao.jpg", "P�o fresco e quente 3" 1.50);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (3, "P�o 4", "resource/imagens/pao.jpg", "P�o fresco e quente 4" 0.20);


insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (4, "Banana", "resource/imagens/banana.jpg", "fruta 1", 0.50);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (4, "Batata", "resource/imagens/batata.jpg", "fruta 1", 0.20);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (4, "Banana 2", "resource/imagens/banana.jpg", "fruta 2", 0.30);
insert into produto (idCategoria, nome, descricao, urlImagem, preco) values (4, "Batata 3", "resource/imagens/batata.jpg", "fruta 3", 0.40)