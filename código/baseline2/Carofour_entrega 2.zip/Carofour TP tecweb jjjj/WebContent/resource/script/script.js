
$(document).ready(function() {
			$('#formulario').validate({
				rules:{
						nome:{
								required: true,
								minlength: 3
							},
							
						email:{
								required: true,
								email: true
							},	
							
						sexo:{
								required: true,
								maxlength: 1,	
							},	
							
						senha:{
							required: true,
							minlength: 6
							},	
							
							datNascimento:{
								required:true,
								date: true
								
							},
							
						endereco:{
							required:true,
							minlength: 4
							},	
							
						telefone:{
							required: true,
							minlength: 10
							},
									
						pagamento:{
							required: true
								},
							
							termos: "required"
						},
		
				messages:{
					nome:{
						required:"O campo nome deve ser preechido.",
						minlength: "O campo nome deve ser preechido com pelo menos 3 caracteres."
					     },
					     
					email:{
						required:"O campo email deve ser preechido.",
						email: "O campo email deve conter um email v�lido."
						},
						
					senha:{
						required:"O campo senha deve ser preechido.",
						minlength: "A senha deve conter entre 6 a 10 caracteres."
						},
						
					sexo:{
						required:"Selecione o sexo.",
						},
						
					datNascimento:{
						required:"O campo data de nascimento deve ser preechido.",
						date:"Informe a data no formato DD/MM/AAAA."
						},
						
					endereco:{
						required:"O campo endere�o deve ser preechido.",
						minlength: "O endere�o deve contrer pelo menos 4 caracteres."
						},	
						
					telefone:{
						required:"O campo telefone deve ser preechido.",
						minlength: "O telefone deve contrer o DDD + numero."
						},
						
					pagamento:{
						required: "Selecione o m�todo de pagamento."
						},
						
						
				}
			});
	
	
		});
	
