

/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojavirtual.carofour.logica.CarrinhoLogica;
import br.com.lojavirtual.carofour.logica.ProdutoLogica;
import br.com.lojavirtual.carofour.modelo.Produto;

@WebServlet(name = "carrinho", urlPatterns = "/carrinho")
public class CarrinhoController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CarrinhoController() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String parametro = request.getParameter("id");
		ProdutoLogica produtoLogica = new ProdutoLogica();
		Produto produto = produtoLogica.pesquisar(Integer.parseInt(parametro));
		
		CarrinhoLogica carrinhoLogica = new CarrinhoLogica();
		carrinhoLogica.adicionar(produto);
		
		String forward = "/carrinho.jsp";
		
    	ArrayList<Produto> listacarrinho = carrinhoLogica.getCarrinho();
		request.setAttribute("listaProduto", listacarrinho);
		request.setAttribute("subtotal1", carrinhoLogica.somaPreco());
		
		// redireciona para pagina da variavel forward
		RequestDispatcher paginaRedirecionada = request.getRequestDispatcher(forward);
		paginaRedirecionada.forward(request, response);

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
}
