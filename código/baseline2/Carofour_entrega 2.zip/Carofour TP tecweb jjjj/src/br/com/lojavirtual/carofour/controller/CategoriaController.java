
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.controller;

import java.io.IOException;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojavirtual.carofour.logica.ProdutoLogica;
import br.com.lojavirtual.carofour.modelo.Produto;

/**
 * Servlet implementation class CategoriaController
 */
@WebServlet(name="categoria",urlPatterns = "/categoria")
public class CategoriaController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public CategoriaController() {
        super();
       
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
 
    	String idCategoria = request.getParameter("id");
    	
    	ProdutoLogica produtologica = new ProdutoLogica();
		//ArrayList<Produto> lista = produtologica.getProduto();//retorna todos os produtos listados em categoria
		
		Set<Produto> lista = produtologica.selecionar(Integer.parseInt(idCategoria));//busca categoria de cada produto
		request.setAttribute("listaProduto", lista);//esta setando tioda a lista de produtos no parametro de resposta lista produto
		
		String forward = "/categoria.jsp";
		//redireciona para pagina da variavel forward
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);

    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
    	// TODO Auto-generated method stub
    	super.doPost(req, resp);
    }
      
}
