
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;






import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojavirtual.carofour.logica.CarrinhoLogica;
import br.com.lojavirtual.carofour.logica.ClienteLogica;
import br.com.lojavirtual.carofour.modelo.Cliente;
import br.com.lojavirtual.carofour.modelo.Produto;

@WebServlet(name = "cliente", urlPatterns = "/cliente")
public class ClienteController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyy");

		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String senha = request.getParameter("senha");
		String data = request.getParameter("datNascimento");
		String sexo = request.getParameter("sexo");
		String endereco = request.getParameter("endereco");
		String telefone = request.getParameter("telefone");

		Date date = null;
		try {
			date = formatter.parse(data);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		
		Cliente cliente = new Cliente(1, nome, email, senha, date, sexo,
				endereco, telefone);

		ClienteLogica clienteLogica = new ClienteLogica();
		ArrayList<Cliente> retornaCliente = clienteLogica.adicionarCliente(cliente);

		String forward = "/confirmacao.jsp";
		
		CarrinhoLogica carrinhoLogica = new CarrinhoLogica();
    	ArrayList<Produto> listacarrinho = carrinhoLogica.getCarrinho();

    	System.out.println(retornaCliente);
    	request.setAttribute("listaProduto", listacarrinho);
    	request.setAttribute("listaClientes", retornaCliente);
		
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
		
		
	}

	
}
