
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojavirtual.carofour.logica.CarrinhoLogica;

@WebServlet(name = "fechamento", urlPatterns = "/fechamento")
public class FechamentoController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FechamentoController() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		
		int frete= 10;
		CarrinhoLogica carrinhoLogica = new CarrinhoLogica();
		request.setAttribute("subtotal", carrinhoLogica.somaPreco());
		request.setAttribute("frete", carrinhoLogica.somaPreco()+frete);
		String forward = "/fechamento.jsp";//fechamento
		
		// redireciona para pagina da variavel forward
		if(carrinhoLogica.retornaTamanhocarrinho()==0)
		{
			forward = "/carrinhovazio.jsp";
			RequestDispatcher view = request.getRequestDispatcher(forward);
			view.forward(request, response);
		}
		else{
			RequestDispatcher view = request.getRequestDispatcher(forward);
			view.forward(request, response);
		}
		
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String forward = "/confirmacao.jsp";//confirma�ao
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);

	}

}
