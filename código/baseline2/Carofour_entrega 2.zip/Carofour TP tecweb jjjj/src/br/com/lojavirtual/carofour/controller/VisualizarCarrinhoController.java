
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.lojavirtual.carofour.logica.CarrinhoLogica;
import br.com.lojavirtual.carofour.modelo.Produto;

@WebServlet(name = "visualizar", urlPatterns = "/visualizar")
public class VisualizarCarrinhoController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String forward = "/carrinho.jsp";
		
		CarrinhoLogica carrinhoLogica = new CarrinhoLogica();
    	ArrayList<Produto> listacarrinho = carrinhoLogica.getCarrinho();
		request.setAttribute("listaProduto", listacarrinho);

		
		// redireciona para pagina da variavel forward
		RequestDispatcher paginaRedirecionada = request.getRequestDispatcher(forward);
		paginaRedirecionada.forward(request, response);
	}

}
