
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.dao;

import java.sql.SQLException;
import java.util.List;

import br.com.lojavirtual.carofour.modelo.Categoria;

public interface CategoriaDAO {
	
	public void adiciona(Categoria categoria);
	public List<Categoria> getlistaCategoria() throws SQLException;
    public void delete(Categoria categoria);


}