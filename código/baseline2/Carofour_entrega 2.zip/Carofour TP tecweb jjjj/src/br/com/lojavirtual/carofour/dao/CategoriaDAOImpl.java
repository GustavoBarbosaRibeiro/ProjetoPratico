/**
 * @author Gustavo Riberio
 *
 */
package br.com.lojavirtual.carofour.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.lojavirtual.carofour.modelo.Categoria;


public class CategoriaDAOImpl implements CategoriaDAO{

	private Connection connection;

	public CategoriaDAOImpl() {
		this.connection = new ConnectionFactory().getConnection();

	}
	public void adiciona(Categoria categoria) {
		
	}
	public List<Categoria> getlistaCategoria() throws SQLException {

		String sql = "SELECT * FROM Categoria;";
		PreparedStatement stmt = null;
		List<Categoria> listaCategoria = new ArrayList<Categoria>();

		try {
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Categoria Categoria = new Categoria(rs.getInt("idCategoria"),
						rs.getString("nome"), rs.getString("Urlimagem"));
				listaCategoria.add(Categoria);
			}
			return listaCategoria;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}

	}
	
	public void delete(Categoria categoria) {
		
	}
}