
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.dao;

import java.sql.SQLException;
import java.util.List;

import br.com.lojavirtual.carofour.modelo.Cliente;

public interface ClienteDAO {

	public void adiciona(Cliente cliente) throws SQLException;
	public List<Cliente> getlistaClientes() throws SQLException;
	public void update(Cliente cliente) throws SQLException;
	public void deletaCliente(Cliente cliente) throws SQLException;
}
