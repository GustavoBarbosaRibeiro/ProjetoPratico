/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.dao;

import java.util.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.lojavirtual.carofour.modelo.Cliente;

public class ClienteDAOImpl implements ClienteDAO{

	private Connection connection;

	public ClienteDAOImpl() {
		this.connection = new ConnectionFactory().getConnection();

	}

	public void adiciona(Cliente cliente) throws SQLException {
		String sql = "insert into cliente"
				+ "(nomeCompleto, email, senha, dataNascimento, sexo, endereco, telefone)"
				+ " values (?,?,?,?,?,?,?)";
		PreparedStatement stmt = null;

		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, cliente.getNomeCompleto());
			stmt.setString(2, cliente.getEmail());
			stmt.setString(3, cliente.getSenha());
			stmt.setDate(4, new Date(cliente.getDataNascimento().getTime()));
			stmt.setString(5, cliente.getSexo());
			stmt.setString(6, cliente.getEndereco());
			stmt.setString(7, cliente.getTelefone());
			stmt.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}
	}

	public List<Cliente> getlistaClientes() throws SQLException {

		String sql = "SELECT * FROM CLIENTE;";
		PreparedStatement stmt = null;
		List<Cliente> listaClientes = new ArrayList<Cliente>();

		try {
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Cliente cliente = new Cliente(rs.getLong("idCliente"),
						rs.getString("nomeCompleto"), rs.getString("email"),
						rs.getString("senha"), rs.getDate("dataNascimento"),
						rs.getString("endereco"), rs.getString("telefone"),
						rs.getString("sexo"));
				listaClientes.add(cliente);

			}
			return listaClientes;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}

	}

	public void update(Cliente cliente) throws SQLException {
		String sql = "insert into cliente"
				+ "(nomeCompleto, email, senha, dataNascimento, sexo, endereco, telefone)"
				+ " values (?,?,?,?,?,?,?)";
		PreparedStatement stmt = null;

		try {
			
			stmt = connection.prepareStatement(sql);

			stmt.setString(1, cliente.getNomeCompleto());
			stmt.setString(2, cliente.getEmail());
			stmt.setString(3, cliente.getSenha());
			stmt.setDate(4, new Date(cliente.getDataNascimento().getTime()));
			stmt.setString(5, cliente.getSexo());
			stmt.setString(6, cliente.getEndereco());
			stmt.setString(7, cliente.getTelefone());

			stmt.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}
	}
	
	public void deletaCliente(Cliente cliente) throws SQLException {

		String sql = "delete from cliente;";
		PreparedStatement stmt = null;

		try {
			stmt = connection.prepareStatement(sql);
			stmt.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}
	}

	public static void main(String[] args) throws SQLException {
		Connection connection = new ConnectionFactory().getConnection();

		System.out.println("Conex�o aberta!");
		String sql = "select * from cliente;";

		PreparedStatement stm = connection.prepareStatement(sql);
		ResultSet rs = stm.executeQuery();
		List<Cliente> listaClientes = new ArrayList<Cliente>();

		while (rs.next()) {
			while (rs.next()) {
				Cliente cliente = new Cliente(rs.getLong("idCliente"),
						rs.getString("nomeCompleto"), rs.getString("email"),
						rs.getString("senha"), rs.getDate("dataNascimento"),
						rs.getString("endereco"), rs.getString("telefone"),
						rs.getString("sexo"));
				listaClientes.add(cliente);

				for (Cliente texto : listaClientes)
					System.out.print(texto);

			}
		}
	}
}
