
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.dao;

import java.sql.SQLException;
import java.util.List;

import br.com.lojavirtual.carofour.modelo.ItemPedido;

public interface ItemPedidoDAO {
	
	public void adiciona(ItemPedido ItemPedido) throws SQLException;
	public List<ItemPedido> getlistaItemPedidos() throws SQLException;
	public void update(ItemPedido ItemPedido);
	public void deletaItemPedido(ItemPedido ItemPedido) throws SQLException;
	
	
	

}
