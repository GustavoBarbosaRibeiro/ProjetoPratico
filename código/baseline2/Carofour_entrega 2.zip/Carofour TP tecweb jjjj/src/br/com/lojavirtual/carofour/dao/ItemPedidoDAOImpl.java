/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.dao;

import java.util.*;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.lojavirtual.carofour.modelo.ItemPedido;

public class ItemPedidoDAOImpl implements ItemPedidoDAO{

	private Connection connection;

	public ItemPedidoDAOImpl() {
		this.connection = new ConnectionFactory().getConnection();

	}

	public void adiciona(ItemPedido ItemPedido) throws SQLException {
		String sql = "insert into ItemPedido"
				+ "(quantidade)"
				+ " values (?)";
		PreparedStatement stmt = null;

		try {
			stmt = connection.prepareStatement(sql);
			stmt.setInt(1, ItemPedido.getQuantidade());
			
			stmt.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}
	}

	public List<ItemPedido> getlistaItemPedidos() throws SQLException {

		String sql = "SELECT * FROM ItemPedido;";
		PreparedStatement stmt = null;
		List<ItemPedido> listaItemPedidos = new ArrayList<ItemPedido>();

		try {
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				ItemPedido ItemPedido = new ItemPedido(rs.getLong("idItemPedido"),
						rs.getInt("quantidade"));
				listaItemPedidos.add(ItemPedido);

			}
			return listaItemPedidos;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}

	}

	public void update(ItemPedido ItemPedido) {
		
		}

	
	public void deletaItemPedido(ItemPedido ItemPedido) throws SQLException {

		String sql = "delete from ItemPedido;";
		PreparedStatement stmt = null;

		try {
			stmt = connection.prepareStatement(sql);
			stmt.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}
	}


	}

