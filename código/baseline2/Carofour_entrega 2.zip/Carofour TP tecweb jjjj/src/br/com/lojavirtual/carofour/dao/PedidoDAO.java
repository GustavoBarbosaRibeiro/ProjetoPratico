
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.dao;

import java.sql.SQLException;
import java.util.List;

import br.com.lojavirtual.carofour.modelo.Pedido;

public interface PedidoDAO {

	public void adiciona(Pedido Pedido);
	public void update(Pedido Pedido);
	public List<Pedido> getlistaPedido() throws SQLException;
	public void delete(Pedido Pedido);
	
}
