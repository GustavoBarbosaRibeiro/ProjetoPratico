/**
 * @author Gustavo Riberio
 *
 */
package br.com.lojavirtual.carofour.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.lojavirtual.carofour.modelo.Pedido;


public class PedidoDAOImpl implements PedidoDAO {

	private Connection connection;

	public PedidoDAOImpl() {
		this.connection = new ConnectionFactory().getConnection();

	}

	public void adiciona(Pedido Pedido) {
		String sql = "insert into Pedido "
				+ "(numero)" + "(item)"
				+ " values (?,?)";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setInt(1, Pedido.getNumero());
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}
	
	public void update(Pedido Pedido) {
		String sql = "insert into Pedido "
				+ "(numero)" + "(item)"
				+ " values (?)";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setInt(1, Pedido.getNumero());
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}
	
	
	public List<Pedido> getlistaPedido() throws SQLException {

		String sql = "SELECT * FROM Pedido;";
		PreparedStatement stmt = null;
		List<Pedido> listaPedido = new ArrayList<Pedido>();

		try {
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Pedido Pedido = new Pedido(rs.getLong("idPedido"), null, rs.getInt("numero"));
				listaPedido.add(Pedido);
			}
			return listaPedido;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}

	}
	
	public void delete(Pedido Pedido) {
	
		}

	}



