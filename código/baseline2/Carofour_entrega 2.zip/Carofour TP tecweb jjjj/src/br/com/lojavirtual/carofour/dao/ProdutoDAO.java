
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.dao;

import java.sql.SQLException;
import java.util.List;

import br.com.lojavirtual.carofour.modelo.Produto;

public interface ProdutoDAO {

	public void adiciona(Produto Produto) throws SQLException;
	public List<Produto> getlistaProdutosporID(int idCategoria) throws SQLException;
	public void update(Produto Produto) throws SQLException;
	public void deletaProduto(Produto Produto) throws SQLException;
}
