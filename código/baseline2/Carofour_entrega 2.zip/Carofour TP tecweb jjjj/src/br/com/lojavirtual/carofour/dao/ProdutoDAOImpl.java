/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.dao;

import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.lojavirtual.carofour.modelo.Produto;

public class ProdutoDAOImpl {

	private Connection connection;

	public ProdutoDAOImpl() {
		this.connection = new ConnectionFactory().getConnection();

	}

	public void adiciona(Produto Produto) throws SQLException {

	}

	public List<Produto> getlistaProdutos() throws SQLException {

		String sql = "SELECT * FROM Produto;";
		PreparedStatement stmt = null;
		List<Produto> listaProdutos = new ArrayList<Produto>();

		try {
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Produto Produto = new Produto(rs.getLong("idProduto"),
						rs.getString("nome"), rs.getString("urlimagem"),
						rs.getString("descricao"), rs.getDouble("preco"),
						null);
				listaProdutos.add(Produto);

			}
			return listaProdutos;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}

	}

	public List<Produto> getlistaProdutosporID(int idCategoria) throws SQLException {

		String sql = "SELECT * FROM Produto whiere idCategoria = ?;";
		PreparedStatement stmt = null;
		List<Produto> listaProdutos = new ArrayList<Produto>();

		try {
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Produto Produto = new Produto(rs.getLong("idProduto"),
						rs.getString("nome"), rs.getString("urlimagem"),
						rs.getString("descricao"), rs.getDouble("preco"),
						null);
				listaProdutos.add(Produto);

			}
			return listaProdutos;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			connection.close();
			stmt.close();
		}

	}
	
	public void update(Produto Produto) throws SQLException {

	}

	public void deletaProduto(Produto Produto) throws SQLException {

	}

}
