
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.logica;

import java.util.*;

import br.com.lojavirtual.carofour.modelo.Produto;

public class CarrinhoLogica {

	public static ArrayList<Produto> carrinho = new ArrayList<>();
	int quant =0;
	public CarrinhoLogica() {

	}

	
	public void adicionar(Produto produto) {
		carrinho.add(produto);
	}
	

	public void limpar() {
		carrinho.clear();
		//System.out.println("array" + carrinho.get(0));
	}
	public int retornaTamanhocarrinho() {
		return carrinho.size();
	}

	public double somaPreco() {
		double soma = 0.0;
		for (Produto elemento : carrinho) {
			soma += elemento.getPreco();
		}
		return soma;
	}

	public ArrayList<Produto> getCarrinho() {
		return carrinho;
	}

}