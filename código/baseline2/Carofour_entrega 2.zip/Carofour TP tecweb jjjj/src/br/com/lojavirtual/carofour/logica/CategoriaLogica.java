
/**
 * @author Gustavo Riberio
 *
 */
package br.com.lojavirtual.carofour.logica;

import java.util.ArrayList;

import br.com.lojavirtual.carofour.modelo.Categoria;

public class CategoriaLogica {

	public ArrayList<Categoria> Listacategoria = null;

	public CategoriaLogica() {

		Listacategoria = new ArrayList<>();
		Listacategoria.add(new Categoria(1, "Latic�nios", "resource/imagens/laticinios.jpg"));
		Listacategoria.add(new Categoria(2, "Carnes", "resource/imagens/carnes.jpg"));
		Listacategoria.add(new Categoria(3, "Padaria", "resource/imagens/padaria.jpg"));
		Listacategoria.add(new Categoria(4, "Hortifrutigranjeiros", "resource/imagens/hortifrutigranjeiros.jpg"));

	}


	public Categoria retornaCategoria(int id) {

		return  Listacategoria.get(id-1);

	}
}
