
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.logica;

import java.util.ArrayList;

import br.com.lojavirtual.carofour.modelo.Cliente;

public class ClienteLogica {

	public static  ArrayList<Cliente> listaCliente = new ArrayList<>();

	public ClienteLogica() {

	}

	public ArrayList<Cliente> adicionarCliente(Cliente Cliente) {
		if(listaCliente.size() > 0)
		{
			listaCliente.clear();
		}
		listaCliente.add(Cliente);
		return listaCliente;
	}

	public long retornaidCliente(int id) {

		Cliente cliente = listaCliente.get(id);
		return cliente.getIdCliente();
	}
	
	public ArrayList<Cliente> retornaCliente() {
		return listaCliente;
	}

}
