
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.logica;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import br.com.lojavirtual.carofour.modelo.Produto;

public class ProdutoLogica {

	public static  ArrayList<Produto> produto = new ArrayList<>();

	public ProdutoLogica() {

		
		
		
		produto.add(new Produto(1, "Leite 1", "resource/imagens/leite.jpg", "O puro leite de vaca", 1.00, new CategoriaLogica().retornaCategoria(1)));
		produto.add(new Produto(2, "Leite 2", "resource/imagens/leite.jpg", "O puro leite de vaca 2", 2.00, new CategoriaLogica().retornaCategoria(1)));
		produto.add(new Produto(3, "Leite 3", "resource/imagens/leite.jpg", "O puro leite de vaca 3", 4.00, new CategoriaLogica().retornaCategoria(1)));
		produto.add(new Produto(4, "Leite 4", "resource/imagens/leite.jpg", "O puro leite de vaca 4", 0.50, new CategoriaLogica().retornaCategoria(1)));
		
		
		produto.add(new Produto(5, "Carne 1", "resource/imagens/coxa.jpg", "A pura carne", 2.00, new CategoriaLogica().retornaCategoria(2)));
		produto.add(new Produto(6, "Carne 2", "resource/imagens/coxa.jpg", "A pura carne 2", 3.00, new CategoriaLogica().retornaCategoria(2)));
		produto.add(new Produto(7, "Carne 3", "resource/imagens/pernil.jpg", "A pura carne 3", 10.00, new CategoriaLogica().retornaCategoria(2)));
		produto.add(new Produto(8, "Carne 4", "resource/imagens/pernil.jpg", "A pura carne 4", 12.00, new CategoriaLogica().retornaCategoria(2)));
		
		
		produto.add(new Produto(9, "P�o 1", "resource/imagens/pao.jpg", "P�o fresco e quente", 0.40, new CategoriaLogica().retornaCategoria(3)));
		produto.add(new Produto(10, "P�o 2", "resource/imagens/pao.jpg", "P�o fresco e quente 2", 0.50, new CategoriaLogica().retornaCategoria(3)));
		produto.add(new Produto(11, "P�o 3", "resource/imagens/pao.jpg", "P�o fresco e quente 3", 1.50, new CategoriaLogica().retornaCategoria(3)));
		produto.add(new Produto(12, "P�o 4", "resource/imagens/pao.jpg", "P�o fresco e quente 4", 0.20, new CategoriaLogica().retornaCategoria(3)));
		produto.add(new Produto(13, "P�o 5", "resource/imagens/pao.jpg", "P�o fresco e quente 5", 1.20, new CategoriaLogica().retornaCategoria(3)));
		
		
		produto.add(new Produto(14, "Banana", "resource/imagens/banana.jpg", "fruta 1", 0.50, new CategoriaLogica().retornaCategoria(4)));
		produto.add(new Produto(15, "Batata", "resource/imagens/batata.jpg", "fruta 1", 0.20, new CategoriaLogica().retornaCategoria(4)));
		produto.add(new Produto(16, "Banana 2", "resource/imagens/banana.jpg", "fruta 2", 0.30, new CategoriaLogica().retornaCategoria(4)));
		produto.add(new Produto(17, "Batata 3", "resource/imagens/batata.jpg", "fruta 3", 0.40, new CategoriaLogica().retornaCategoria(4)));

	}

	public ArrayList<Produto> getProduto() {
		return produto;
	}

	public Produto pesquisar(int indice) {
		return produto.get(indice - 1);
	}

	public void remover(int indice) {
		produto.remove(indice);
	}
	
	public Set<Produto> selecionar(int id){
		
		Set<Produto> produtolista = new HashSet<>();
		for (Produto texto : produto) {
			if(id == texto.getCategoria().getIdCategoria())
			produtolista.add(texto);
			}
		return produtolista;
		
	}
	
	
}
