
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.modelo;
public class Categoria {
	
	private int idCategoria;
	private String nome;
	private String urlimagem;
	
	public Categoria(int idCategoria, String nome, String urlimagem) {
		super();
		this.idCategoria = idCategoria;
		this.nome = nome;
		this.urlimagem = urlimagem;
	}
	
	public int getIdCategoria() {
		return idCategoria;
	}
	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getUrlimagem() {
		return urlimagem;
	}
	public void setUrlimagem(String urlimagem) {
		this.urlimagem = urlimagem;
	}

	@Override
	public String toString() {
		return "Categoria [idCategoria=" + idCategoria + ", nome=" + nome
				+ ", urlimagem=" + urlimagem + "]";
	}
	
	
	
}
