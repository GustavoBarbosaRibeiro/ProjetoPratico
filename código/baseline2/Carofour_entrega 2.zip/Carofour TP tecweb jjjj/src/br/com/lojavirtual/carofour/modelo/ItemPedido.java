
/**
 * @author Gustavo Riberio
 *
 */


package br.com.lojavirtual.carofour.modelo;
public class ItemPedido extends Produto {
	
	private long idItemPedido;
	private int quantidade;

	public ItemPedido(long idItemPedido, int quantidade) {
		super();
		this.idItemPedido = idItemPedido;
		this.quantidade = quantidade;
	}

	public long getIdItemPedido() {
		return idItemPedido;
	}

	public void setIdItemPedido(long idItemPedido) {
		this.idItemPedido = idItemPedido;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + quantidade;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemPedido other = (ItemPedido) obj;
		if (quantidade != other.quantidade)
			return false;
		return true;
	}
	
	

}
