
/**
 * @author Gustavo Riberio
 *
 */

package br.com.lojavirtual.carofour.modelo;


public class Pedido {
	
	private long idPedido;
	private ItemPedido item;
	private int numero;
	
	
	
	public Pedido(long idPedido, ItemPedido item, int numero) {
		super();
		this.idPedido = idPedido;
		this.item = item;
		this.numero = numero;
	}

	
	public long getIdPedido() {
		return idPedido;
	}
	public void setIdPedido(long idPedido) {
		this.idPedido = idPedido;
	}
	public ItemPedido getItem() {
		return item;
	}
	public void setItem(ItemPedido item) {
		this.item = item;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((item == null) ? 0 : item.hashCode());
		result = prime * result + numero;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pedido other = (Pedido) obj;
		if (item == null) {
			if (other.item != null)
				return false;
		} else if (!item.equals(other.item))
			return false;
		if (numero != other.numero)
			return false;
		return true;
	}
	
	

}
